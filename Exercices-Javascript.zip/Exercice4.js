let idees = [
    "Faire un tour en ville",
    "Balade en voiture",
    "Regarder un film sur Netflix",
    "Lire un livre"

]
for(let element of idees){
    console.log(idees[0]);
    break;
}

