const pays = 'Maroc';
function capital(){
    switch (pays){
    case 'France' :
    console.log('Paris');
    break;
    case 'Allemagne' :
    console.log('Berlin');
    break;
    case 'Italie' :
    console.log('Rome');
    break;
    case 'Maroc' :
    console.log('Rabat');
    break;
    case 'Espagne' :
    console.log('Madrid');
    break
    case 'Portugal' :
    console.log('Lisbonne');
    break
    case 'Angleterre' :
    console.log('Londres');
    break
    case 'Tout autre pays' :
    console.log('Inconnu');
    break
    }   
}
return capital()