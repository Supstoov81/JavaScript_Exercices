const str1 = "Test"
const str2 = "Affichage"
function affichePhrase(str1, str2){
    return str1 , str2
}
console.log('«',  str1 , '|' , str2, '».')