function surfaceTriangle(a,b){
    return (a * b)/2
}
console.log(surfaceTriangle(7,10))