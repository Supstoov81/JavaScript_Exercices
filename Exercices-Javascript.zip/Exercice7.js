const nombre1 = 16
const nombre2 = 8
function PairImpair(nombre1,nombre2){
    if(nombre1 %2 == 0 && nombre2 %2 == 0){
       console.log("pair")
       
    }
    else{
        console.log("impair")
    }
}
return PairImpair()