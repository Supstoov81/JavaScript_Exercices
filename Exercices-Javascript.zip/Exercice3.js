let num1 = 25
let num2 = 30
let num3 = 40
function numLePlusGrand(){
    if(num1>num2 && num1>num3){
        console.log(num1)
    }
    else if(num2>num1 && num2>num3){
        console.log(num2)
    }
    else if(num3>num1 && num3>num2){
        console.log(num3)
    }
}
return numLePlusGrand()
