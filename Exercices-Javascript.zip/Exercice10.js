
function compterNbVoyelles(mot) {
    let nbVoyelles = 0;
    for (i = 0; i < mot.length; i++) {
        var lettre = mot[i].toLowerCase();
        if ((lettre === "a") || (lettre === "e") || (lettre === "i") || (lettre ==="o") || (lettre === "u") || (lettre === "y")) {
            nbVoyelles ++;
        }
    }
    return nbVoyelles;
}
 
console.log("le nombre de voyelles est : " + compterNbVoyelles("Je suis motivé pour apprendre"));
